var searchData=
[
  ['tamanho_5fmax_0',['TAMANHO_MAX',['../fila_8h.html#a8ca29d56e79dc1a062c7068a88b2ab08',1,'fila.h']]]
];
