var searchData=
[
  ['printartarefas_0',['printarTarefas',['../main_8c.html#a29f99034699aa32cec59008421860092',1,'main.c']]]
];
