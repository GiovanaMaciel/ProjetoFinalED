var searchData=
[
  ['t_0',['T',['../atividade_8h.html#a9582e6e8e21f2a935d9f19fc744bc7a4',1,'T():&#160;atividade.h'],['../fila_8h.html#a9582e6e8e21f2a935d9f19fc744bc7a4',1,'T():&#160;fila.h']]]
];
