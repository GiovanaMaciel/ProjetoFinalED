var searchData=
[
  ['t_0',['T',['../atividade_8h.html#a9582e6e8e21f2a935d9f19fc744bc7a4',1,'T():&#160;atividade.h'],['../fila_8h.html#a9582e6e8e21f2a935d9f19fc744bc7a4',1,'T():&#160;fila.h']]],
  ['tamanho_5fmax_1',['TAMANHO_MAX',['../fila_8h.html#a8ca29d56e79dc1a062c7068a88b2ab08',1,'fila.h']]],
  ['topico_2',['topico',['../structatividade.html#a009a534e423bb59a697946f0a6ed3f27',1,'atividade']]]
];
