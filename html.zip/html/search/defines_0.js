var searchData=
[
  ['max_0',['MAX',['../main_8c.html#a392fb874e547e582e9c66a08a1f23326',1,'main.c']]],
  ['max_5ftarefa_1',['MAX_TAREFA',['../atividade_8h.html#aa77869b90f8c0ec041b4135091914823',1,'atividade.h']]]
];
