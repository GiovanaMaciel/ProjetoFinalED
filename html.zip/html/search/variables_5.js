var searchData=
[
  ['posicao_0',['posicao',['../structiterador.html#ad88022ced77288087b47f1c29a668f06',1,'iterador']]],
  ['prev_1',['prev',['../structnode.html#a7f9f45e1d1feffda166957ea5a51bb76',1,'node']]],
  ['primeiro_2',['primeiro',['../structfila.html#ac98fd0e5d15fcee11f5b1c8ba95c2c88',1,'fila']]]
];
