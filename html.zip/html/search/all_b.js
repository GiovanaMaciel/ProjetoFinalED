var searchData=
[
  ['s_0',['S',['../atividade_8h.html#a0c6231495c60aa5059cab9cd68a51d02',1,'atividade.h']]],
  ['sentinela_1',['sentinela',['../structlista.html#a6b86d9b7174a0351f79805631a4f1785',1,'lista']]]
];
