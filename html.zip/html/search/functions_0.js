var searchData=
[
  ['fdestroi_0',['fDestroi',['../fila_8c.html#ae0b8eadcc3c59cdcd89d5dcbd44f358c',1,'fDestroi(fila *f):&#160;fila.c'],['../fila_8h.html#ae0b8eadcc3c59cdcd89d5dcbd44f358c',1,'fDestroi(fila *f):&#160;fila.c']]],
  ['finicializa_1',['fInicializa',['../fila_8c.html#a7de4e2b3a189009e1d007af878cd2a53',1,'fInicializa():&#160;fila.c'],['../fila_8h.html#a7de4e2b3a189009e1d007af878cd2a53',1,'fInicializa():&#160;fila.c']]],
  ['finsere_2',['fInsere',['../fila_8c.html#a7dbdedc1c0b72598423967972625797d',1,'fInsere(fila *f, A atv):&#160;fila.c'],['../fila_8h.html#ab0625ec79c7c041c24afecdb6b2ac941',1,'fInsere(fila *f, A atvf):&#160;fila.c']]],
  ['fremove_3',['fRemove',['../fila_8c.html#a44ca5d769912825246b71b1bc580f515',1,'fRemove(fila *f):&#160;fila.c'],['../fila_8h.html#a44ca5d769912825246b71b1bc580f515',1,'fRemove(fila *f):&#160;fila.c']]],
  ['ftamanho_4',['fTamanho',['../fila_8c.html#a69378c7da230ffdae910b3a9103e1ad0',1,'fTamanho(fila *f):&#160;fila.c'],['../fila_8h.html#a69378c7da230ffdae910b3a9103e1ad0',1,'fTamanho(fila *f):&#160;fila.c']]],
  ['fvazia_5',['fVazia',['../fila_8c.html#a5b42d46167028c5b96f6af94ca2a1f40',1,'fVazia(fila *f):&#160;fila.c'],['../fila_8h.html#a5b42d46167028c5b96f6af94ca2a1f40',1,'fVazia(fila *f):&#160;fila.c']]]
];
