var indexSectionsWithContent =
{
  0: "adefilmnpqrstuv",
  1: "afiln",
  2: "aflmr",
  3: "flmpv",
  4: "ademnpqstu",
  5: "anst",
  6: "mt",
  7: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

