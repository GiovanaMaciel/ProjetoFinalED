var searchData=
[
  ['ano_0',['ano',['../structatividade.html#a1acc132a5d96534d8ae27a7f42ca6e4e',1,'atividade']]],
  ['atividade_1',['atividade',['../structatividade.html#a09b2fcb5d3e33291848ae0ada1b33367',1,'atividade']]],
  ['atvf_2',['atvf',['../structfila.html#a3eac7c0d695bab47eb185d46e499b728',1,'fila']]]
];
