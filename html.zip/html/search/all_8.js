var searchData=
[
  ['posicao_0',['posicao',['../structiterador.html#ad88022ced77288087b47f1c29a668f06',1,'iterador']]],
  ['prev_1',['prev',['../structnode.html#a7f9f45e1d1feffda166957ea5a51bb76',1,'node']]],
  ['primeiro_2',['primeiro',['../structfila.html#ac98fd0e5d15fcee11f5b1c8ba95c2c88',1,'fila']]],
  ['printartarefas_3',['printarTarefas',['../main_8c.html#a29f99034699aa32cec59008421860092',1,'main.c']]],
  ['projeto_20prático_20de_20estrutura_20de_20dados_4',['Projeto prático de Estrutura de Dados',['../md__r_e_a_d_m_e.html',1,'']]]
];
