var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['menor_1',['menor',['../main_8c.html#a0c8bb68a18aaa7f34e54e2d453fefa6f',1,'main.c']]]
];
