var searchData=
[
  ['next_0',['next',['../structnode.html#a0dc1b6470487aa86d9936e3cab8b95be',1,'node']]],
  ['node_1',['node',['../structnode.html',1,'']]],
  ['node_2',['Node',['../listaordenada_8h.html#ac09cf950484bd9550d14d602b0e5e7fb',1,'listaordenada.h']]]
];
