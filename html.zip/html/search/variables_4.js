var searchData=
[
  ['next_0',['next',['../structnode.html#a0dc1b6470487aa86d9936e3cab8b95be',1,'node']]]
];
