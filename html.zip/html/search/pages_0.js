var searchData=
[
  ['projeto_20prático_20de_20estrutura_20de_20dados_0',['Projeto prático de Estrutura de Dados',['../md__r_e_a_d_m_e.html',1,'']]]
];
