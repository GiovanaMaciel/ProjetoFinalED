var searchData=
[
  ['verificadata_0',['verificaData',['../main_8c.html#a7c621bde1afe397acfd0bb7f6cab0e38',1,'main.c']]]
];
