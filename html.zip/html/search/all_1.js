var searchData=
[
  ['data_0',['data',['../structnode.html#ab930b3075b248119b41fb45f3bbf6885',1,'node']]],
  ['dia_1',['dia',['../structatividade.html#a69a8c58d1a8ad8a652137a76358473e2',1,'atividade']]]
];
